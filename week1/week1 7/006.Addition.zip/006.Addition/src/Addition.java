public class Addition {

    public static void main(String[] args) {

        int a = 1337;
        int b = 42;
        int result = a + b; // Fix this

        String toPrint = a + " + " + b + " = " + result;
        System.out.println(toPrint);

    }

}
